#必要なモジュールをインポート
import datetime
import smtplib
import ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import pandas as pd






#メーリングリスト読み込み
df = pd.read_excel('mailing_list.xlsx')
df

#エンコード指定
import sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

#送信元の設定
gmail_account = "testtarosyukatsuyo@gmail.com"
gmail_password = "test20210319"

#日時要素の指定
today_date = datetime.date.today()
delivery_date = today_date + datetime.timedelta(days=1)
print(today_date,delivery_date)

#メール内容を関数化
def gmail_send(send_name, mail_to, filename):
    
    #メールタイトルと本文(本文はHTML形式)
    subject = "{0},{1}分の打刻はしたのか？".format(send_name,today_date)
    body = '''打刻しなかったら大変なことになるぞ。<br>
              添付ファイルのようにな。<br>
              タイムリミットは{0}だ。'''.format(delivery_date)

    #内容確認
    print(subject)
    print(body)

    msg = MIMEMultipart()

    msg["Subject"] = subject
    msg["To"] = mail_to
    msg["From"] = gmail_account
    msg_body = MIMEText(body,"html")
    print(msg)

    msg.attach(msg_body)

    filename = filename
    file = open(filename,"rb")

    #ファイルを添付
    attachment_file = MIMEBase('application','pdf')
    attachment_file.set_payload((file).read())
    file.close()

    encoders.encode_base64(attachment_file)
    attachment_file.add_header('Content-Disposition',"attachment", filename=filename)
    msg.attach(attachment_file)




    server = smtplib.SMTP_SSL("smtp.gmail.com",465,context=ssl.create_default_context())
    server.login(gmail_account, gmail_password)
    server.send_message(msg)
    server.close()
    print('送信完了')

#メーリングリストのすべての宛先にmeil_sendの処理を繰り返し行う
def send_multiple_gmails():
    for send_name, mail_to, filename in zip(df['宛名'],df['メールアドレス'],df['添付ファイル']):
        gmail_send(send_name, mail_to,filename)


#定期実行
import schedule
import time

# schedule.every(10).seconds.do(send_multiple_gmails)
schedule.every().day.at("23:00").do(send_multiple_gmails)

while True:
    schedule.run_pending()
    time.sleep(1)   